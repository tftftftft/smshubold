import requests

base_url = "https://api.smspool.net/"

